﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeamProject
{
    public class User
    {
        public int? Age { get; set; }
        public double? Weight { get; set; }
        public string Sex { get; set; }
        public double? WidmarK { get; set; }
        public string AlcoholType { get; set; }

        public User()
        {

        }
    }
}
