﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeamProject
{
    public class Conditions
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public double Concentration { get; set; }

        public Conditions()
        {

        }


    }
}
