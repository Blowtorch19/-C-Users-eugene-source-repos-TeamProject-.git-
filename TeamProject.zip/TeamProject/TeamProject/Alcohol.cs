﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeamProject
{
    public class Alcohol
    {
        public string Name { get; set; }
        public int AlcoholicBeverage { get; set; }

        public Alcohol(string name, int alcoholicBeverage)
        {
            name = Name;
            alcoholicBeverage = AlcoholicBeverage;
        }

        public Alcohol()
        {
            
        }
    }
}
