﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeamProject
{
    public class UserConditions
    {
        public string Name { get; set; }
        public double? Volume { get; set; }
        public double? Hours { get; set; }

        public UserConditions()
        {

        }
    }
}
